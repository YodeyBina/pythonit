@echo off
setlocal
chcp 65001 >nul
set "APP=%~dp0pythonit.py"

rem Prefer real Python installations over the Microsoft Store execution aliases.
if exist "%UserProfile%\AppData\Local\Python\bin\python.exe" (
  "%UserProfile%\AppData\Local\Python\bin\python.exe" "%APP%"
  goto :done
)
for /d %%D in ("%UserProfile%\AppData\Local\Programs\Python\Python*") do (
  if exist "%%~fD\python.exe" (
    "%%~fD\python.exe" "%APP%"
    goto :done
  )
)
py -3 "%APP%"
if errorlevel 1 python "%APP%"
:done
if errorlevel 1 (
  echo.
  echo לא נמצא Python תקין. התקינו Python מ-python.org ונסו שוב.
  pause
)
endlocal
