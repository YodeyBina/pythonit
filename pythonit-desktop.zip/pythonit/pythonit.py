#!/usr/bin/env python3
"""פייתונית - גרסת שולחן עבודה. מריץ פייתון אמיתי מקומית, כולל קלט אינטראקטיבי. ללא התקנות נוספות."""
import os, sys, json, time, base64, shutil, secrets, subprocess, tempfile, threading, webbrowser, importlib.util, traceback
import codecs, re, mimetypes
from urllib.parse import urlparse, parse_qs, unquote
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

BASE = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
TOKEN = secrets.token_urlsafe(24)
with open(os.path.join(BASE, "pythonit.html"), encoding="utf-8") as f:
    PAGE = f.read().replace("</head>", "<script>window.PYIT_TOKEN=%s</script></head>" % json.dumps(TOKEN), 1)


def choose_workdir():
    """Choose a user-writable workspace, even on locked-down Windows profiles."""
    choices = [
        os.path.join(os.path.expanduser("~"), "Pythonit"),
        os.path.join(os.environ.get("LOCALAPPDATA", ""), "Pythonit"),
        os.path.join(os.getcwd(), "Pythonit-data"),
    ]
    for folder in choices:
        if not folder or folder == "Pythonit":
            continue
        try:
            os.makedirs(folder, exist_ok=True)
            probe = os.path.join(folder, ".write-test")
            with open(probe, "w", encoding="utf-8") as f:
                f.write("")
            os.remove(probe)
            probe_dir = tempfile.mkdtemp(dir=folder, prefix=".directory-test-")
            os.rmdir(probe_dir)
            return folder
        except OSError:
            continue
    raise RuntimeError("לא נמצאה תיקייה זמינה לשמירת קבצי פייתונית.")


WORK = choose_workdir()  # כאן נשמרים קבצים שהקוד שלכם יוצר
RUNS = os.path.join(WORK, ".runtime")  # private temp area; avoids fragile system Temp permissions
os.makedirs(RUNS, exist_ok=True)
LAUNCH_LOG = os.path.join(WORK, "pythonit-launch.log")


def launch_log(message):
    """Small local diagnostic log for startup issues; never sent anywhere."""
    try:
        with open(LAUNCH_LOG, "a", encoding="utf-8") as f:
            f.write("[%s] %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), message))
    except OSError:
        pass


def find_python():
    if not getattr(sys, "frozen", False):
        return sys.executable
    return next((p for p in (shutil.which(n) for n in ("python3", "python", "py")) if p), None)


PY = find_python()
ping = [time.time(), False]

# Packages are checked locally; nothing is downloaded or sent over the network.
POPULAR_PACKAGES = ("numpy", "pandas", "matplotlib", "requests", "PIL", "sklearn", "bs4", "plotly",
                    "openpyxl", "pygame", "scipy", "seaborn", "tkinter", "flask")

# ---------------------------------------------------------------------------
# The runner wraps the student's program. It makes input() / sys.stdin tell the
# app "I am waiting for the user" (so the page can show an input box exactly
# there), turns plt.show() into pictures inside the output panel, and prints
# clean tracebacks that point at main.py.
# ---------------------------------------------------------------------------
RUNNER_SRC = r'''
import sys, os, types, linecache, traceback

PATH, NONCE = sys.argv[1], sys.argv[2]
RUNDIR = os.path.dirname(PATH)
_real_out = sys.stdout


def _mark(kind, payload=""):
    try:
        _real_out.write("\x1e%s:%s:%s\x1f" % (NONCE, kind, payload))
        _real_out.flush()
    except Exception:
        pass


class _Stdin(object):
    def __init__(self, real):
        self._r = real
    def readline(self, *a):
        _mark("in")
        return self._r.readline(*a)
    def read(self, *a):
        _mark("in")
        return self._r.read(*a)
    def readlines(self, *a):
        _mark("in")
        return self._r.readlines(*a)
    def __iter__(self):
        return self
    def __next__(self):
        line = self.readline()
        if not line:
            raise StopIteration
        return line
    def __getattr__(self, name):
        return getattr(self._r, name)


_stdin = _Stdin(sys.stdin)
sys.stdin = _stdin


def _input(prompt=""):
    if prompt is not None and prompt != "":
        sys.stdout.write(str(prompt))
    sys.stdout.flush()
    try:
        sys.stderr.flush()
    except Exception:
        pass
    line = _stdin.readline()
    if not line:
        raise EOFError("EOF when reading a line")
    if line.endswith("\n"):
        line = line[:-1]
    if line.endswith("\r"):
        line = line[:-1]
    return line


import builtins
builtins.input = _input

try:
    src = open(PATH, encoding="utf-8").read()
except Exception as e:
    sys.stderr.write("לא ניתן לקרוא את הקוד: %s\n" % e)
    sys.exit(1)

_flush_figs = None
if any(w in src for w in ("matplotlib", "pyplot", "pylab", "seaborn", "pandas")):
    try:
        os.environ["MPLBACKEND"] = "Agg"
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as _plt
        _count = [0]

        def _flush_figs(*args, **kwargs):
            for num in list(_plt.get_fignums()):
                fig = _plt.figure(num)
                _count[0] += 1
                name = "fig%d.png" % _count[0]
                try:
                    fig.savefig(os.path.join(RUNDIR, name), dpi=110, bbox_inches="tight",
                                facecolor=fig.get_facecolor())
                except Exception:
                    continue
                _mark("img", name)
            _plt.close("all")

        _plt.show = _flush_figs
    except Exception:
        _flush_figs = None

cwd = os.getcwd()
if sys.path:
    sys.path[0] = cwd
else:
    sys.path.insert(0, cwd)
sys.argv = ["main.py"]
linecache.cache["main.py"] = (len(src), None, src.splitlines(True), "main.py")
module = types.ModuleType("__main__")
module.__file__ = "main.py"
module.__builtins__ = builtins
sys.modules["__main__"] = module

status = 0
try:
    exec(compile(src, "main.py", "exec"), module.__dict__)
except SystemExit as e:
    c = e.code
    if c is None:
        status = 0
    elif isinstance(c, int):
        status = c
    else:
        sys.stderr.write(str(c) + "\n")
        status = 1
except BaseException:
    etype, evalue, tb = sys.exc_info()
    if isinstance(evalue, SyntaxError):
        tb = None
    elif tb is not None:
        tb = tb.tb_next
    try:
        sys.stdout.flush()
    except Exception:
        pass
    traceback.print_exception(etype, evalue, tb)
    status = 1

if _flush_figs:
    try:
        _flush_figs()
    except Exception:
        pass
try:
    sys.stdout.flush()
    sys.stderr.flush()
except Exception:
    pass
sys.exit(status)
'''
RUNNER_PATH = os.path.join(RUNS, "pythonit_runner.py")
try:
    with open(RUNNER_PATH, "w", encoding="utf-8") as _f:
        _f.write(RUNNER_SRC)
except OSError as _e:
    launch_log("Could not write runner: %s" % _e)


# ---------------------------------------------------------------------------
# Work-folder files: list / preview / open / upload / delete (always inside WORK)
# ---------------------------------------------------------------------------
MAX_UPLOAD = 300 * 1024 * 1024
MAX_PREVIEW = 40 * 1024 * 1024


def safe_path(rel):
    root = os.path.realpath(WORK)
    p = os.path.realpath(os.path.join(root, rel or ""))
    if p != root and not p.startswith(root + os.sep):
        return None
    if ".runtime" in os.path.relpath(p, root).split(os.sep):
        return None
    return p


def list_files():
    out, root = [], os.path.realpath(WORK)

    def walk(d, depth):
        try:
            entries = sorted(os.scandir(d), key=lambda e: e.name.lower())
        except OSError:
            return
        for e in entries:
            if e.name.startswith(".") or e.name in ("__pycache__", "pythonit-launch.log"):
                continue
            try:
                st = e.stat()
            except OSError:
                continue
            rel = os.path.relpath(e.path, root).replace(os.sep, "/")
            if e.is_dir():
                if depth < 3:
                    walk(e.path, depth + 1)
            elif len(out) < 600:
                out.append({"p": rel, "size": st.st_size, "t": int(st.st_mtime * 1000)})
    walk(root, 0)
    return {"dir": WORK, "files": out}


def os_open(path, reveal=False):
    try:
        if sys.platform.startswith("win"):
            if reveal and os.path.isfile(path):
                subprocess.Popen(["explorer", "/select,", os.path.normpath(path)])
            else:
                os.startfile(path)
        elif sys.platform == "darwin":
            subprocess.Popen(["open", "-R", path] if reveal and os.path.isfile(path) else ["open", path])
        else:
            subprocess.Popen(["xdg-open", os.path.dirname(path) if reveal and os.path.isfile(path) else path])
        return True
    except Exception:
        return False

MAX_OUTPUT_CHARS = 3_000_000
MAX_LIMIT = 6 * 3600


class Session(object):
    """One running program: its process, the events it produced and its input pipe."""

    def __init__(self, code, limit, cmd=None):
        self.id = secrets.token_urlsafe(9)
        self.events = []
        self.cv = threading.Condition()
        self.done = False
        self.proc = None
        self.limit = limit  # seconds of *active* run time; 0 = unlimited. Waiting for input is not counted.
        self.nonce = secrets.token_hex(8)
        self.started = time.time()
        self.waiting_since = None
        self.waited = 0.0
        self.chars = 0
        self.last_poll = time.time()
        self.killed_reason = None
        self.finished_at = None
        self.dir = tempfile.mkdtemp(dir=RUNS, prefix="run-")
        self.path = os.path.join(self.dir, "main.py")
        with open(self.path, "w", encoding="utf-8") as f:
            f.write(code)
        env = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUTF8="1", PYTHONUNBUFFERED="1")
        env["PIP_DISABLE_PIP_VERSION_CHECK"] = "1"
        self.proc = subprocess.Popen(cmd or [PY, "-u", RUNNER_PATH, self.path, self.nonce],
                                     stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                     cwd=WORK, env=env, bufsize=0)
        self.threads = [
            threading.Thread(target=self._read, args=(self.proc.stdout, "out"), daemon=True),
            threading.Thread(target=self._read, args=(self.proc.stderr, "err"), daemon=True),
        ]
        for t in self.threads:
            t.start()
        threading.Thread(target=self._watch, daemon=True).start()

    # -- events -----------------------------------------------------------
    def emit(self, kind, data="", **extra):
        with self.cv:
            ev = {"k": kind, "d": data}
            ev.update(extra)
            self.events.append(ev)
            self.cv.notify_all()

    def _read(self, stream, kind):
        dec = codecs.getincrementaldecoder("utf-8")(errors="replace")
        buf = ""
        while True:
            try:
                chunk = stream.read(4096)
            except (OSError, ValueError):
                break
            if not chunk:
                break
            buf = self._drain(kind, buf + dec.decode(chunk).replace("\r\n", "\n"))
        buf += dec.decode(b"", final=True)
        if buf:
            self._text(kind, buf)

    def _drain(self, kind, buf):
        """Split stdout into plain text and the runner's private markers (input requests, figures)."""
        if kind != "out":
            if buf:
                self._text(kind, buf)
            return ""
        prefix = "\x1e" + self.nonce + ":"
        while True:
            i = buf.find("\x1e")
            if i < 0:
                if buf:
                    self._text(kind, buf)
                return ""
            j = buf.find("\x1f", i)
            if j < 0:
                if len(buf) - i > 400:  # not a real marker
                    self._text(kind, buf[:i + 1])
                    buf = buf[i + 1:]
                    continue
                if i > 0:
                    self._text(kind, buf[:i])
                return buf[i:]  # keep the unfinished marker for the next chunk
            if i > 0:
                self._text(kind, buf[:i])
            m, buf = buf[i:j + 1], buf[j + 1:]
            if m.startswith(prefix):
                self._marker(m[len(prefix):-1])
            else:
                self._text(kind, m)

    def _text(self, kind, text):
        self.chars += len(text)
        if self.chars > MAX_OUTPUT_CHARS and not self.killed_reason:
            self.killed_reason = "הריצה הופסקה כי הפלט הגיע לגודל מופרז (בדקו אם יש לולאה אינסופית)."
            self.kill()
            return
        if self.chars <= MAX_OUTPUT_CHARS:
            self.emit(kind, text)

    def _marker(self, body):
        kind, _, payload = body.partition(":")
        if kind == "in":
            if self.waiting_since is None:
                self.waiting_since = time.time()
            self.emit("input")
        elif kind == "img":
            name = os.path.basename(payload)
            try:
                with open(os.path.join(self.dir, name), "rb") as f:
                    data = base64.b64encode(f.read()).decode("ascii")
                self.emit("img", "data:image/png;base64," + data)
            except OSError:
                pass

    # -- control ----------------------------------------------------------
    def write(self, text, eof=False):
        if self.done or not self.proc or self.proc.poll() is not None:
            return False
        if self.waiting_since is not None:
            self.waited += time.time() - self.waiting_since
            self.waiting_since = None
        try:
            if text:
                self.proc.stdin.write(text.encode("utf-8"))
                self.proc.stdin.flush()
            if eof:
                self.proc.stdin.close()
        except (OSError, ValueError):
            return False
        return True

    def kill(self):
        try:
            if self.proc and self.proc.poll() is None:
                self.proc.kill()
        except OSError:
            pass

    def active_seconds(self):
        waiting = (time.time() - self.waiting_since) if self.waiting_since else 0.0
        return time.time() - self.started - self.waited - waiting

    def _watch(self):
        while self.proc.poll() is None:
            time.sleep(0.15)
            if self.limit and not self.killed_reason and self.active_seconds() > self.limit:
                self.killed_reason = "הריצה הופסקה אחרי %s (מגבלת הזמן בהגדרות). זמן ההמתנה לקלט אינו נספר." % (
                    "%d שניות" % self.limit if self.limit < 120 else "%d דקות" % (self.limit // 60))
                self.kill()
            if time.time() - self.last_poll > 90 and not self.killed_reason:  # the page went away
                self.killed_reason = "העמוד נסגר."
                self.kill()
        for t in self.threads:
            t.join(2.0)
        code = self.proc.returncode
        if self.killed_reason:
            self.emit("err", "\n[%s]\n" % self.killed_reason)
            code = -1
        self.emit("end", "", code=code, sec=round(time.time() - self.started - self.waited, 2))
        with self.cv:
            self.done = True
            self.finished_at = time.time()
            self.cv.notify_all()
        try:
            self.proc.stdin.close()
        except Exception:
            pass
        shutil.rmtree(self.dir, ignore_errors=True)

    def poll(self, since, wait=12.0):
        self.last_poll = time.time()
        end = time.time() + wait
        with self.cv:
            while len(self.events) <= since and not self.done:
                left = end - time.time()
                if left <= 0:
                    break
                self.cv.wait(left)
            return {"ev": self.events[since:], "n": len(self.events), "done": self.done}


SESSIONS = {}
SLOCK = threading.Lock()


def sweep():
    now = time.time()
    with SLOCK:
        for sid in [k for k, s in SESSIONS.items() if s.done and s.finished_at and now - s.finished_at > 120]:
            SESSIONS.pop(sid, None)


# import name -> pip package name, where they differ
PIP_NAMES = {"PIL": "Pillow", "sklearn": "scikit-learn", "bs4": "beautifulsoup4", "cv2": "opencv-python",
             "yaml": "PyYAML", "skimage": "scikit-image", "dateutil": "python-dateutil", "docx": "python-docx",
             "dotenv": "python-dotenv", "Crypto": "pycryptodome", "jwt": "PyJWT", "attr": "attrs",
             "git": "GitPython", "serial": "pyserial", "OpenSSL": "pyOpenSSL", "magic": "python-magic"}
PKG_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,60}$")


def start_install(name):
    """pip install of one package into the Python that runs the student's code (only on explicit request)."""
    name = (name or "").split(".")[0]
    if not PKG_RE.match(name):
        return None, "שם ספרייה לא תקין."
    importlib.invalidate_caches()
    return start_session("", 900, cmd=[PY, "-m", "pip", "install", PIP_NAMES.get(name, name)])


def start_session(code, limit, cmd=None):
    if not PY:
        return None, "לא נמצא פייתון מותקן במחשב. התקינו מ-python.org."
    sweep()
    try:
        limit = max(0, min(int(limit), MAX_LIMIT))
    except (TypeError, ValueError):
        limit = 300
    try:
        s = Session(code, limit, cmd)
    except OSError as e:
        return None, "לא ניתן היה להפעיל את פייתון: %s" % e
    with SLOCK:
        for old in list(SESSIONS.values()):  # one program at a time
            if not old.done:
                old.killed_reason = old.killed_reason or "הופסקה כי הופעלה ריצה חדשה."
                old.kill()
        SESSIONS[s.id] = s
    return s, None


class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def host_ok(self): return self.headers.get("Host", "").split(":")[0] in ("127.0.0.1", "localhost")

    def authed(self): return self.host_ok() and self.headers.get("X-Token") == TOKEN

    def reply(self, code, body, ct="application/json; charset=utf-8"):
        b = body.encode("utf-8")
        self.send_response(code); self.send_header("Content-Type", ct)
        self.send_header("Content-Length", str(len(b))); self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            self.wfile.write(b)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def reply_bytes(self, code, b, ct):
        self.send_response(code); self.send_header("Content-Type", ct)
        self.send_header("Content-Length", str(len(b))); self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            self.wfile.write(b)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def do_GET(self):
        u = urlparse(self.path)
        if u.path == "/" and self.host_ok(): self.reply(200, PAGE, "text/html; charset=utf-8")
        elif u.path == "/ping" and self.authed():
            ping[0], ping[1] = time.time(), True; self.reply(200, "{}")
        elif u.path == "/libraries" and self.authed():
            importlib.invalidate_caches()
            available = {name: importlib.util.find_spec(name) is not None for name in POPULAR_PACKAGES}
            self.reply(200, json.dumps({"python": sys.version.split()[0], "available": available}))
        elif u.path == "/files" and self.authed():
            self.reply(200, json.dumps(list_files()))
        elif u.path == "/file" and self.authed():
            p = safe_path(unquote((parse_qs(u.query).get("p") or [""])[0]))
            if not p or not os.path.isfile(p): return self.reply(404, "{}")
            if os.path.getsize(p) > MAX_PREVIEW: return self.reply(413, "{}")
            with open(p, "rb") as f:
                self.reply_bytes(200, f.read(), mimetypes.guess_type(p)[0] or "application/octet-stream")
        elif u.path == "/poll" and self.authed():
            q = parse_qs(u.query)
            s = SESSIONS.get((q.get("id") or [""])[0])
            if not s: return self.reply(404, json.dumps({"error": "gone"}))
            try: since = max(0, int((q.get("since") or ["0"])[0]))
            except ValueError: since = 0
            self.reply(200, json.dumps(s.poll(since)))
        else: self.reply(404, "{}")

    def do_POST(self):
        if not self.authed(): return self.reply(403, "{}")
        if self.path.startswith("/upload"):
            return self.do_upload()
        try:
            d = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}")
        except Exception:
            return self.reply(400, "{}")
        try:
            if self.path == "/start":
                s, err = start_session(str(d.get("code", "")), d.get("limit", 300))
                self.reply(200, json.dumps({"id": s.id} if s else {"error": err}))
            elif self.path in ("/open", "/reveal"):
                p = safe_path(str(d.get("p", "")))
                ok = bool(p) and os.path.exists(p) and os_open(p, reveal=self.path == "/reveal")
                self.reply(200, json.dumps({"ok": ok}))
            elif self.path == "/delete":
                p = safe_path(str(d.get("p", "")))
                ok = False
                if p and os.path.isfile(p):
                    try: os.remove(p); ok = True
                    except OSError: pass
                self.reply(200, json.dumps({"ok": ok}))
            elif self.path == "/install":
                s, err = start_install(str(d.get("name", "")))
                self.reply(200, json.dumps({"id": s.id} if s else {"error": err}))
            elif self.path == "/stdin":
                s = SESSIONS.get(str(d.get("id", "")))
                ok = bool(s) and s.write(str(d.get("text", "")), bool(d.get("eof")))
                self.reply(200, json.dumps({"ok": ok}))
            elif self.path == "/stop":
                s = SESSIONS.get(str(d.get("id", "")))
                if s and not s.done:
                    s.killed_reason = s.killed_reason or "הריצה הופסקה."
                    s.kill()
                self.reply(200, "{}")
            else:
                self.reply(404, "{}")
        except Exception as e:
            self.reply(200, json.dumps({"error": "שגיאה פנימית: %s" % e}))


def _upload(self):
    q = parse_qs(urlparse(self.path).query)
    name = os.path.basename(unquote((q.get("name") or [""])[0]).replace("\\", "/"))
    n = int(self.headers.get("Content-Length", 0))
    if not name or name.startswith(".") or n > MAX_UPLOAD:
        return self.reply(400, json.dumps({"error": "שם קובץ לא תקין או שהקובץ גדול מדי"}))
    base, ext = os.path.splitext(name)
    dest, i = os.path.join(WORK, name), 1
    while os.path.exists(dest):  # never overwrite an existing file
        dest = os.path.join(WORK, "%s (%d)%s" % (base, i, ext)); i += 1
    try:
        with open(dest, "wb") as f:
            left = n
            while left > 0:
                chunk = self.rfile.read(min(1 << 16, left))
                if not chunk: break
                f.write(chunk); left -= len(chunk)
    except OSError as e:
        return self.reply(200, json.dumps({"error": "שמירה נכשלה: %s" % e}))
    self.reply(200, json.dumps({"name": os.path.basename(dest)}))


H.do_upload = _upload


def serve():
    for port in range(47631, 47651):  # פורט קבוע כדי שהפרויקטים השמורים יישארו בין הפעלות
        try: return ThreadingHTTPServer(("127.0.0.1", port), H), port
        except OSError: continue
    raise SystemExit("לא נמצא פורט פנוי")


def open_app(url):
    try:  # חלון מקורי, אם מותקן: pip install pywebview
        import webview
        webview.create_window("פייתונית", url, width=1380, height=860)
        webview.start(); return True
    except Exception: pass
    cands = [shutil.which(n) for n in ("google-chrome", "chromium", "chrome", "msedge", "microsoft-edge")]
    for root in filter(None, (os.environ.get("ProgramFiles"), os.environ.get("ProgramFiles(x86)"), os.environ.get("LOCALAPPDATA"))):
        cands += [os.path.join(root, r) for r in (r"Google\Chrome\Application\chrome.exe", r"Microsoft\Edge\Application\msedge.exe")]
    cands += ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome", "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"]
    for c in cands:
        if c and os.path.exists(c):
            subprocess.Popen([c, "--app=" + url, "--window-size=1380,860"]); return False
    webbrowser.open(url); return False


def main():
    try:
        srv, port = serve()
    except Exception:
        launch_log("Server startup failed:\n" + traceback.format_exc())
        print("פייתונית לא הצליחה להיפתח. פרטים: " + LAUNCH_LOG)
        raise
    launch_log("Listening on 127.0.0.1:%d with %s" % (port, PY or "no Python runtime"))
    # A non-daemon server keeps the app available even if the browser launcher misbehaves.
    threading.Thread(target=srv.serve_forever, daemon=False, name="PythonitServer").start()

    def watchdog():  # fail-safe only: browsers may suspend background tabs briefly
        while True:
            time.sleep(15)
            if ping[1] and time.time() - ping[0] > 20 * 60: os._exit(0)
    threading.Thread(target=watchdog, daemon=True).start()
    url = "http://127.0.0.1:%d/" % port
    print("פייתונית פועלת ב-" + url + "\nסגרו את החלון כדי לצאת (או Ctrl+C).")
    if os.environ.get("PYIT_NOOPEN"):
        while True: time.sleep(1)
    try:
        if open_app(url):
            srv.shutdown()
            return
    except Exception:
        launch_log("Browser launcher failed:\n" + traceback.format_exc())
        webbrowser.open(url)
    try:
        while True: time.sleep(1)
    except KeyboardInterrupt: pass


if __name__ == "__main__":
    main()
